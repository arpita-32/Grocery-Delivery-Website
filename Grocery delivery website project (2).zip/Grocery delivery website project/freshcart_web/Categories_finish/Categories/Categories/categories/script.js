document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart as an empty array to store cart items
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Update the cart count in the navigation bar
    const cartCount = document.getElementById('cart-count');
    cartCount.textContent = cart.length;

    // Add event listener to all "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll('.cart-btn');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();

            // Get product details from the clicked product box
            const productBox = button.closest('.product-box');
            const productName = productBox.querySelector('strong').textContent;
            const quantity = productBox.querySelector('.quantity').textContent;
            const price = productBox.querySelector('.price').textContent;
            const image = productBox.querySelector('img').src; // Get image URL

            // Create a product object with the retrieved details
            const product = {
                name: productName,
                quantity: quantity,
                price: price,
                image: image // Include image URL
            };

            // Add the product to the cart
            cart.push(product);

            // Update the cart count in the navigation bar
            cartCount.textContent = cart.length;

            // Store the updated cart in localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
        });
    });

    // JavaScript for smooth scrolling
    document.querySelectorAll('a[href^="*"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});