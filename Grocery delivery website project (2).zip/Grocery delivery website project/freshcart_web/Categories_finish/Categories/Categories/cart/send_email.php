<?php

// Allow from any origin
header("Access-Control-Allow-Origin: http://127.0.0.1:5500"); // Adjust the origin to match your frontend server

// Other CORS headers if needed
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Continue with your PHP code
// ...

// Allow from any origin
//header("Access-Control-Allow-Origin: *"); // Allow requests from any origin during development

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    }

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }

    exit(0);
}

// Check if email parameter is provided
if (isset($_POST['email'])) {
    // Get the email address from the POST parameters
    $recipientEmail = $_POST['email'];

    // Debugging: Log the received email address
    error_log("Received email address: " . $recipientEmail);

    // Create a new PHPMailer instance
    $mail = new PHPMailer\PHPMailer\PHPMailer();

    // Debugging: Log the creation of PHPMailer instance
    error_log("Created PHPMailer instance");

    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'rishikaagarwal2316@gmail.com'; // Your Gmail address
    $mail->Password = 'qhbh dhti keem dlf'; // Your Gmail password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Email content
    $mail->setFrom('rishikaagarwal2316@gmail.com', 'Your Name');
    $mail->addAddress($recipientEmail); // Recipient email address
    $mail->Subject = 'Test Email';
    $mail->Body = 'This is a test email sent from PHP using Gmail SMTP.';

    // Send the email
    if (!$mail->send()) {
        // Debugging: Log error message if email sending fails
        error_log("Failed to send email: " . $mail->ErrorInfo);

        // Return an error message if the email sending fails
        echo json_encode(['success' => false, 'error' => 'Failed to send email.']);
    } else {
        // Return a success message if the email is sent successfully
        echo json_encode(['success' => true]);

        // Debugging: Log success message
        error_log("Email sent successfully");
    }
} else {
    // Debugging: Log error if no email address provided
    error_log("No email address provided");

    // Return an error message if the email parameter is not provided
    echo json_encode(['success' => false, 'error' => 'No email address provided.']);
}
?>
