const search = () => {
    const searchBox = document.getElementById("search-item").value.toUpperCase();
    const products = document.querySelectorAll(".product");

    products.forEach(product => {
        const productName = product.querySelector("h1");
        const textValue = productName.textContent || productName.innerText;

        if (textValue.toUpperCase().indexOf(searchBox) > -1) {
            product.style.display = "";
        } else {
            product.style.display = "none";
        }
    });
}